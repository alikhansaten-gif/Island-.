package com.example.island

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun prefs() = getSharedPreferences("island", MODE_PRIVATE)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(48), dp(20), dp(20))
        }
        fun button(label: String, onClick: () -> Unit) = Button(this).apply {
            text = label; setOnClickListener { onClick() }
            root.addView(this)
        }
        fun label(t: String) = TextView(this).apply {
            text = t; setPadding(0, dp(16), 0, 0); root.addView(this)
        }

        root.addView(TextView(this).apply {
            text = "Dynamic Island"; textSize = 24f; gravity = Gravity.CENTER
        })

        button("1. Разрешить «Поверх других приложений»") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")))
        }
        button("2. Доступ к уведомлениям") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        button("3. Запустить остров") {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Сначала выдай шаг 1", Toast.LENGTH_SHORT).show()
            } else startForegroundService(Intent(this, IslandService::class.java))
        }
        button("Остановить остров") { stopService(Intent(this, IslandService::class.java)) }
        button("Тест уведомления") {
            IslandService.instance?.show("Тест", "Остров работает 🎉")
                ?: Toast.makeText(this, "Остров не запущен", Toast.LENGTH_SHORT).show()
        }

        label("Отступ сверху (dp)")
        root.addView(seek(0, 60, prefs().getInt("y", 8)) { prefs().edit().putInt("y", it).apply() })
        label("Ширина острова (dp)")
        root.addView(seek(60, 200, prefs().getInt("w", 110)) { prefs().edit().putInt("w", it).apply() })

        button("Применить положение") {
            if (IslandService.instance != null)
                startService(Intent(this, IslandService::class.java).setAction("REFRESH"))
        }
        button("Отключить оптимизацию батареи") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun seek(min: Int, max: Int, cur: Int, onChange: (Int) -> Unit) =
        SeekBar(this).apply {
            this.max = max - min
            progress = cur - min
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { onChange(p + min) }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
}
