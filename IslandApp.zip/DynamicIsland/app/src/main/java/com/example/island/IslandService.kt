package com.example.island

import android.animation.ValueAnimator
import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.LinearLayout
import android.widget.TextView

class IslandService : Service() {

    companion object {
        @Volatile var instance: IslandService? = null
        private const val CHANNEL = "island"
    }

    private lateinit var wm: WindowManager
    private var pill: LinearLayout? = null
    private var params: WindowManager.LayoutParams? = null
    private lateinit var titleView: TextView
    private lateinit var textView: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val collapseRunnable = Runnable { collapse() }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun prefs() = getSharedPreferences("island", Context.MODE_PRIVATE)
    private fun compactW() = dp(prefs().getInt("w", 110))
    private fun compactH() = dp(32)
    private fun expandedW() = dp(320)
    private fun expandedH() = dp(72)

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager

        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Island", NotificationManager.IMPORTANCE_MIN)
        )
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("Dynamic Island работает")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()
        startForeground(1, n)
        createPill()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "REFRESH") { removePill(); createPill() }
        return START_STICKY
    }

    private fun createPill() {
        titleView = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 13f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END
        }
        textView = TextView(this).apply {
            setTextColor(Color.LTGRAY); textSize = 12f
            maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END
        }
        val v = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), 0, dp(18), 0)
            background = GradientDrawable().apply {
                setColor(Color.BLACK); cornerRadius = dp(100).toFloat()
            }
            addView(titleView); addView(textView)
        }
        titleView.visibility = android.view.View.GONE
        textView.visibility = android.view.View.GONE

        val lp = WindowManager.LayoutParams(
            compactW(), compactH(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(prefs().getInt("y", 8))
        }
        wm.addView(v, lp)
        pill = v; params = lp
    }

    private fun removePill() {
        handler.removeCallbacks(collapseRunnable)
        pill?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        pill = null
    }

    fun show(title: String, text: String) {
        handler.post {
            val p = pill ?: return@post
            titleView.text = title
            textView.text = text
            titleView.visibility = android.view.View.VISIBLE
            textView.visibility = if (text.isBlank()) android.view.View.GONE else android.view.View.VISIBLE
            animate(params!!.width, expandedW(), params!!.height, expandedH())
            handler.removeCallbacks(collapseRunnable)
            handler.postDelayed(collapseRunnable, 4000)
        }
    }

    private fun collapse() {
        titleView.visibility = android.view.View.GONE
        textView.visibility = android.view.View.GONE
        animate(params!!.width, compactW(), params!!.height, compactH())
    }

    private fun animate(w0: Int, w1: Int, h0: Int, h1: Int) {
        val lp = params ?: return
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 300
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                val f = it.animatedValue as Float
                lp.width = (w0 + (w1 - w0) * f).toInt()
                lp.height = (h0 + (h1 - h0) * f).toInt()
                pill?.let { v -> try { wm.updateViewLayout(v, lp) } catch (_: Exception) {} }
            }
            start()
        }
    }

    override fun onDestroy() {
        removePill()
        instance = null
        super.onDestroy()
    }
}
